#include <stdio.h>
#include "meio.h"

int main()
{Meio* meios = NULL; // Lista ligada vazia 
		     
 meios = inserirMeio(meios,1,"bicicleta",55,30);
 meios = inserirMeio(meios,2,"bicicleta",85,50);
 meios = inserirMeio(meios,3,"trotinete",85,50);

 listarMeios(meios);

 if (existeMeio(meios, 1)) printf("Meio 1 existe\n");
 else printf("Meio 1 nao existe\n");
 
 if (existeMeio(meios, 4)) printf("Meio 4 existe\n");
 else printf("Meio 4 nao existe\n");

 meios = removerMeio(meios, 1);
 meios = removerMeio(meios, 2);
 meios = removerMeio(meios, 3);
 listarMeios(meios);

 return(0);
}
